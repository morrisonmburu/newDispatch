import Vue from 'vue'
import { Notify } from 'quasar'

Vue.prototype.$notify = Notify
