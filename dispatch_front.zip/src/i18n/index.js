import enUS from './en-us'

export default {
  'en-us': enUS
}
