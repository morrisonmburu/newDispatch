export function orderGetter (state) {
  return state.orderState
}

export function intransitOrderGetter (state) {
  return state.intransitOrder
}
