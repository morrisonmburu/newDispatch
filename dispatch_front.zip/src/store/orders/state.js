export default function () {
  return {
    orderState: [],
    intransitOrder: []
  }
}
