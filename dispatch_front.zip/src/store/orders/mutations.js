export function mutations (state, val) {
  state.orderState = val
}

export function intransitMutations (state, val) {
  state.intransitOrder = val
}
