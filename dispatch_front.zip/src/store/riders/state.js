export default function () {
  return {
    offlineRiders: [],
    onlineRiders: [],
    inactiveRiders: []
  }
}
