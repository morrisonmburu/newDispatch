export function getOfflineRiders (state) {
  return state.offlineRiders
}

export function getOnlineRiders (state) {
  return state.onlineRiders
}

export function getInactiveRiders (state) {
  return state.inactiveRiders
}
