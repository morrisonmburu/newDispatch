export function offlineMutations (state, val) {
  state.offlineRiders = val
}

export function onlineMutations (state, val) {
  state.onlineRiders = val
}

export function inactiveMutations (state, val) {
  state.inactiveRiders = val
}
