export function someGetter (state) {
  return state.state1
}
