export const mutations = (state, val) => {
  state.state1 = val
}
