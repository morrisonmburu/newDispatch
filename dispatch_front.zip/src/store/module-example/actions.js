export function someAction (state, val) {
  state.commit('mutations', 'clicked')
}
