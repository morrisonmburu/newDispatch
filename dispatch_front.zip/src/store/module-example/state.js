export default function () {
  return {
    state1: ''
  }
}
